@echo off
setlocal
cd /d "%~dp0"
call prepare-free-server.bat --content-archive "%~dp0content\published-content.json" --content-sha256 be5669cbb3c7959e6e6ea9c99f95237f03a4bac9f4470f5527f7b2654ab46bd0 %*
set "SETUP_RESULT=%errorlevel%"
echo.
pause
exit /b %SETUP_RESULT%
